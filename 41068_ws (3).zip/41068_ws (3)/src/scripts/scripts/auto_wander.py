#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import numpy as np
import cv2


class AutoWandererDepth(Node):
    def __init__(self):
        super().__init__('auto_wanderer_depth')

        # Parameters
        self.declare_parameter('cmd_vel_topic', 'cmd_vel')
        self.declare_parameter('depth_topic', '/camera/depth/image')
        self.declare_parameter('linear_speed', 0.3)
        self.declare_parameter('angular_speed', 0.6)
        self.declare_parameter('min_range', 1.0)   # Obstacle threshold (meters)
        self.declare_parameter('front_width', 100) # Pixels around center for obstacle check

        self.cmd_vel_topic = self.get_parameter('cmd_vel_topic').get_parameter_value().string_value
        self.depth_topic = self.get_parameter('depth_topic').get_parameter_value().string_value
        self.linear_speed = self.get_parameter('linear_speed').get_parameter_value().double_value
        self.angular_speed = self.get_parameter('angular_speed').get_parameter_value().double_value
        self.min_range = self.get_parameter('min_range').get_parameter_value().double_value
        self.front_width = int(self.get_parameter('front_width').get_parameter_value().integer_value or 100)

        # Publishers
        self.cmd_pub = self.create_publisher(Twist, self.cmd_vel_topic, 10)

        # Subscribers
        self.bridge = CvBridge()
        self.create_subscription(Image, self.depth_topic, self.depth_callback, 10)

        # State
        self.state = "FORWARD"
        self.turn_time = 0

        self.get_logger().info(f"AutoWandererDepth started. Using {self.depth_topic} for obstacle detection.")

    def depth_callback(self, msg: Image):
        try:
            # Convert ROS Image -> numpy
            depth_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding="32FC1")

            h, w = depth_image.shape
            center_x = w // 2

            # Crop a vertical strip in the middle
            roi = depth_image[:, center_x - self.front_width//2:center_x + self.front_width//2]

            # Compute closest distance
            min_dist = np.nanmin(roi)

            twist = Twist()

            if self.state == "FORWARD":
                if min_dist < self.min_range:
                    self.get_logger().warn(f"⚠️ Too close! Obstacle at {min_dist:.2f} m. Turning...")
                    self.state = "TURN"
                    self.turn_time = self.get_clock().now().seconds_nanoseconds()[0] + 3  # turn for ~3s
                else:
                    twist.linear.x = self.linear_speed

            elif self.state == "TURN":
                if self.get_clock().now().seconds_nanoseconds()[0] < self.turn_time:
                    twist.angular.z = self.angular_speed
                else:
                    self.state = "FORWARD"

            self.cmd_pub.publish(twist)

        except Exception as e:
            self.get_logger().error(f"Depth callback error: {e}")


def main():
    rclpy.init()
    node = AutoWandererDepth()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

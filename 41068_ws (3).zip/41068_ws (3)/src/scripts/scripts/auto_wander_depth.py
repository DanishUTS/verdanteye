#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, PoseStamped
from sensor_msgs.msg import Image
from visualization_msgs.msg import Marker
import numpy as np
from cv_bridge import CvBridge
import random
import time


class AutoWanderDepth(Node):
    def __init__(self):
        super().__init__('auto_wander_depth')

        # Parameters
        self.declare_parameter('cmd_vel_topic', 'cmd_vel')
        self.declare_parameter('depth_topic', '/camera/depth/image')
        self.declare_parameter('linear_speed', 0.3)
        self.declare_parameter('angular_speed', 0.6)
        self.declare_parameter('min_range', 0.5)     # obstacle avoidance
        self.declare_parameter('wall_buffer', 0.7)   # keep distance from walls

        self.cmd_vel_topic = self.get_parameter('cmd_vel_topic').value
        self.depth_topic = self.get_parameter('depth_topic').value
        self.linear_speed = self.get_parameter('linear_speed').value
        self.angular_speed = self.get_parameter('angular_speed').value
        self.min_range = self.get_parameter('min_range').value
        self.wall_buffer = self.get_parameter('wall_buffer').value

        # Publishers / Subscribers
        self.cmd_pub = self.create_publisher(Twist, self.cmd_vel_topic, 10)
        self.pose_pub = self.create_publisher(PoseStamped, "robot_pose", 10)
        self.marker_pub = self.create_publisher(Marker, "obstacle_markers", 10)
        self.depth_sub = self.create_subscription(Image, self.depth_topic, self.depth_callback, 10)

        self.bridge = CvBridge()
        self.latest_depth = None

        # Robot "pose" tracker for visualization (very simple dead-reckoning)
        self.x, self.y, self.theta = 0.0, 0.0, 0.0
        self.last_time = time.time()

        # Control loop
        self.timer = self.create_timer(0.1, self.control_loop)

        self.get_logger().info(f"AutoWanderDepth started. Listening to {self.depth_topic}")

    def depth_callback(self, msg: Image):
        try:
            depth_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding="passthrough")
            self.latest_depth = np.nan_to_num(depth_image, nan=10.0, posinf=10.0, neginf=10.0)
        except Exception as e:
            self.get_logger().error(f"Depth conversion failed: {e}")

    def publish_pose(self, twist: Twist):
        """Simple dead-reckoning pose publisher for RViz path visualization"""
        now = time.time()
        dt = now - self.last_time
        self.last_time = now

        # Update robot pose (simplified odometry)
        self.x += twist.linear.x * np.cos(self.theta) * dt
        self.y += twist.linear.x * np.sin(self.theta) * dt
        self.theta += twist.angular.z * dt

        pose_msg = PoseStamped()
        pose_msg.header.stamp = self.get_clock().now().to_msg()
        pose_msg.header.frame_id = "map"
        pose_msg.pose.position.x = self.x
        pose_msg.pose.position.y = self.y
        pose_msg.pose.orientation.z = np.sin(self.theta / 2.0)
        pose_msg.pose.orientation.w = np.cos(self.theta / 2.0)

        self.pose_pub.publish(pose_msg)

    def publish_obstacle_marker(self, distance, angle, idx):
        """Publish obstacle markers to RViz"""
        marker = Marker()
        marker.header.stamp = self.get_clock().now().to_msg()
        marker.header.frame_id = "base_link"
        marker.ns = "obstacles"
        marker.id = idx
        marker.type = Marker.SPHERE
        marker.action = Marker.ADD
        marker.pose.position.x = distance * np.cos(angle)
        marker.pose.position.y = distance * np.sin(angle)
        marker.pose.position.z = 0.2
        marker.scale.x = 0.2
        marker.scale.y = 0.2
        marker.scale.z = 0.2
        marker.color.r = 1.0
        marker.color.g = 0.0
        marker.color.b = 0.0
        marker.color.a = 1.0
        self.marker_pub.publish(marker)

    def control_loop(self):
        if self.latest_depth is None:
            return

        h, w = self.latest_depth.shape

        # Divide into 3 regions
        left_region   = self.latest_depth[h//3:2*h//3, :w//3]
        center_region = self.latest_depth[h//3:2*h//3, w//3:2*w//3]
        right_region  = self.latest_depth[h//3:2*h//3, 2*w//3:]

        min_left   = np.min(left_region)
        min_center = np.min(center_region)
        min_right  = np.min(right_region)

        self.get_logger().info(
            f"Distances - Left: {min_left:.2f} m | Center: {min_center:.2f} m | Right: {min_right:.2f} m"
        )

        twist = Twist()

        # === 1. Corner detection ===
        if min_center < self.min_range and min_left < self.min_range and min_right < self.min_range:
            self.get_logger().warn("⚠️ Corner detected! Reversing and turning...")
            twist.linear.x = -0.2
            twist.angular.z = self.angular_speed
        # === 2. Obstacle ahead ===
        elif min_center < self.min_range:
            if min_left > min_right:
                self.get_logger().warn("⚠️ Obstacle ahead! Turning LEFT.")
                twist.angular.z = self.angular_speed
            elif min_right > min_left:
                self.get_logger().warn("⚠️ Obstacle ahead! Turning RIGHT.")
                twist.angular.z = -self.angular_speed
            else:
                choice = random.choice(["left", "right"])
                self.get_logger().warn(f"⚠️ Obstacle ahead! Random choice: {choice}")
                twist.angular.z = self.angular_speed if choice == "left" else -self.angular_speed
        # === 3. Path clear → go forward ===
        else:
            twist.linear.x = self.linear_speed
            if min_left < self.wall_buffer:
                self.get_logger().info("Too close LEFT, steering right.")
                twist.angular.z = -0.3
            elif min_right < self.wall_buffer:
                self.get_logger().info("Too close RIGHT, steering left.")
                twist.angular.z = 0.3

        # Publish motion command
        self.cmd_pub.publish(twist)
        # Publish estimated pose for RViz
        self.publish_pose(twist)
        # Publish obstacle markers (show nearest obstacles in RViz)
        self.publish_obstacle_marker(min_center, 0.0, 0)
        self.publish_obstacle_marker(min_left, np.pi/4, 1)
        self.publish_obstacle_marker(min_right, -np.pi/4, 2)


def main():
    rclpy.init()
    node = AutoWanderDepth()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

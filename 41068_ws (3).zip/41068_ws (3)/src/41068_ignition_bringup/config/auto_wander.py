#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
from std_msgs.msg import String
from visualization_msgs.msg import Marker
import math
import time


class AutoWander(Node):
    def __init__(self):
        super().__init__('auto_wander')

        # === Parameters ===
        self.declare_parameter('cmd_vel_topic', 'cmd_vel')
        self.declare_parameter('scan_topic', 'scan')
        self.declare_parameter('linear_speed', 0.5)
        self.declare_parameter('angular_speed', 1.0)
        self.declare_parameter('min_range', 0.8)
        self.declare_parameter('front_arc_deg', 60.0)

        self.cmd_vel_topic = self.get_parameter('cmd_vel_topic').get_parameter_value().string_value
        self.scan_topic = self.get_parameter('scan_topic').get_parameter_value().string_value
        self.linear_speed = self.get_parameter('linear_speed').get_parameter_value().double_value
        self.angular_speed = self.get_parameter('angular_speed').get_parameter_value().double_value
        self.min_range = self.get_parameter('min_range').get_parameter_value().double_value
        self.front_arc = math.radians(
            self.get_parameter('front_arc_deg').get_parameter_value().double_value
        )

        # === Publishers & Subscribers ===
        self.cmd_pub = self.create_publisher(Twist, self.cmd_vel_topic, 10)
        self.alert_pub = self.create_publisher(String, 'object_alert', 10)
        self.marker_pub = self.create_publisher(Marker, 'visualization_marker', 10)
        self.scan_sub = self.create_subscription(LaserScan, self.scan_topic, self.scan_callback, 10)

        # === Timer (10Hz loop) ===
        self.timer = self.create_timer(0.1, self.tick)

        # === State machine ===
        self.state = "FORWARD"
        self.state_end_time = 0.0
        self.last_scan = None

        self.get_logger().info(
            f"AutoWander started. Listening to {self.scan_topic}, publishing to {self.cmd_vel_topic}"
        )

    def scan_callback(self, msg: LaserScan):
        self.last_scan = msg

    def front_blocked(self, scan: LaserScan) -> bool:
        """Check if an obstacle is within the front arc and closer than min_range."""
        if scan is None:
            return False

        n = len(scan.ranges)
        i_center = int(round((0.0 - scan.angle_min) / scan.angle_increment))
        i_span = int(round(self.front_arc / scan.angle_increment))
        i0 = max(0, i_center - i_span)
        i1 = min(n - 1, i_center + i_span)

        for i in range(i0, i1 + 1):
            r = scan.ranges[i]
            if math.isfinite(r) and r > scan.range_min:
                if r < self.min_range:
                    self.publish_alert("⚠️ Object detected ahead!")
                    return True
        return False

    def publish_alert(self, text: str):
        """Publish alert as text and RViz marker."""
        # Text message
        msg = String()
        msg.data = text
        self.alert_pub.publish(msg)

        # Marker for RViz
        marker = Marker()
        marker.header.frame_id = "base_link"
        marker.header.stamp = self.get_clock().now().to_msg()
        marker.ns = "alerts"
        marker.id = 0
        marker.type = Marker.TEXT_VIEW_FACING
        marker.action = Marker.ADD
        marker.pose.position.x = 0.5
        marker.pose.position.y = 0.0
        marker.pose.position.z = 1.0
        marker.scale.z = 0.4
        marker.color.a = 1.0
        marker.color.r = 1.0
        marker.color.g = 0.0
        marker.color.b = 0.0
        marker.text = text
        self.marker_pub.publish(marker)

        self.get_logger().warn(text)

    def tick(self):
        """State machine for wandering behavior."""
        twist = Twist()
        now = time.time()

        if self.last_scan is None:
            return

        if self.state == "FORWARD":
            if self.front_blocked(self.last_scan):
                self.state = "BACK"
                self.state_end_time = now + 0.5
            else:
                twist.linear.x = self.linear_speed

        elif self.state == "BACK":
            if now < self.state_end_time:
                twist.linear.x = -0.3
            else:
                self.state = "TURN_LEFT"
                self.state_end_time = now + 1.0

        elif self.state == "TURN_LEFT":
            if now < self.state_end_time:
                twist.angular.z = self.angular_speed
            else:
                if self.front_blocked(self.last_scan):
                    self.state = "BACK2"
                    self.state_end_time = now + 0.5
                else:
                    self.state = "FORWARD"

        elif self.state == "BACK2":
            if now < self.state_end_time:
                twist.linear.x = -0.3
            else:
                self.state = "TURN_RIGHT"
                self.state_end_time = now + 1.0

        elif self.state == "TURN_RIGHT":
            if now < self.state_end_time:
                twist.angular.z = -self.angular_speed
            else:
                self.state = "FORWARD"

        # Publish velocity command
        self.cmd_pub.publish(twist)


def main(args=None):
    rclpy.init(args=args)
    node = AutoWander()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

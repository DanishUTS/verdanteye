from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.conditions import IfCondition
from launch.substitutions import (
    Command, LaunchConfiguration, PathJoinSubstitution
)
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():

    ld = LaunchDescription()

    # === Paths ===
    pkg_path = FindPackageShare('41068_ignition_bringup')
    config_path = PathJoinSubstitution([pkg_path, 'config'])

    # === Launch Arguments ===
    use_sim_time = LaunchConfiguration('use_sim_time')
    ld.add_action(DeclareLaunchArgument(
        'use_sim_time',
        default_value='True',
        description='Use simulation clock'
    ))

    ld.add_action(DeclareLaunchArgument(
        'rviz',
        default_value='True',
        description='Launch RViz2'
    ))

    ld.add_action(DeclareLaunchArgument(
        'nav2',
        default_value='False',
        description='Launch Nav2 (disabled by default)'
    ))

    ld.add_action(DeclareLaunchArgument(
        'world',
        default_value='large_demo',
        description='World to load',
        choices=['simple_trees', 'large_demo']
    ))

    # === Robot description ===
    robot_description_content = ParameterValue(
        Command(['xacro ',
                 PathJoinSubstitution([pkg_path, 'urdf', 'husky.urdf.xacro'])]),
        value_type=str)

    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[{
            'robot_description': robot_description_content,
            'use_sim_time': use_sim_time
        }]
    )
    ld.add_action(robot_state_publisher)

    # === Localization ===
    ekf = Node(
        package='robot_localization',
        executable='ekf_node',
        name='ekf_filter_node',
        output='screen',
        parameters=[PathJoinSubstitution([config_path, 'robot_localization.yaml']),
                    {'use_sim_time': use_sim_time}]
    )
    ld.add_action(ekf)

    # === Gazebo sim ===
    gazebo = IncludeLaunchDescription(
        PathJoinSubstitution([FindPackageShare('ros_ign_gazebo'),
                              'launch', 'ign_gazebo.launch.py']),
        launch_arguments={
            'ign_args': [PathJoinSubstitution([
                pkg_path, 'worlds', [LaunchConfiguration('world'), '.sdf']
            ]), ' -r']
        }.items()
    )
    ld.add_action(gazebo)

    spawner = Node(
        package='ros_ign_gazebo',
        executable='create',
        output='screen',
        parameters=[{'use_sim_time': use_sim_time}],
        arguments=['-topic', '/robot_description', '-z', '0.4']
    )
    ld.add_action(spawner)

    bridge = Node(
        package='ros_ign_bridge',
        executable='parameter_bridge',
        parameters=[{'config_file': PathJoinSubstitution([config_path, 'gazebo_bridge.yaml']),
                     'use_sim_time': use_sim_time}]
    )
    ld.add_action(bridge)

    # === Depth camera -> LaserScan ===
    depth_to_scan = Node(
        package='depthimage_to_laserscan',
        executable='depthimage_to_laserscan_node',
        name='depth_to_scan',
        output='screen',
        parameters=[{
            'output_frame': 'camera_depth_frame',
            'range_min': 0.3,
            'range_max': 10.0,
            'scan_time': 0.033,
            'use_sim_time': use_sim_time
        }],
        remappings=[
            ('depth/image_rect_raw', '/camera/depth/image'),
            ('depth/camera_info', '/camera/depth/camera_info'),
            ('scan', '/scan')
        ]
    )
    ld.add_action(depth_to_scan)

    # === SLAM Toolbox ===
    slam = IncludeLaunchDescription(
        PathJoinSubstitution([FindPackageShare('slam_toolbox'),
                              'launch', 'online_async_launch.py']),
        launch_arguments={
            'use_sim_time': use_sim_time,
            'slam_params_file': PathJoinSubstitution([config_path, 'slam_params.yaml'])
        }.items()
    )
    ld.add_action(slam)

    # === Nav2 (optional) ===
    nav2 = IncludeLaunchDescription(
        PathJoinSubstitution([FindPackageShare('nav2_bringup'),
                              'launch', 'navigation_launch.py']),
        launch_arguments={
            'use_sim_time': use_sim_time,
            'params_file': PathJoinSubstitution([config_path, 'nav2_params.yaml'])
        }.items(),
        condition=IfCondition(LaunchConfiguration('nav2'))
    )
    ld.add_action(nav2)

    # === RViz ===
    rviz = Node(
        package='rviz2',
        executable='rviz2',
        arguments=['-d', PathJoinSubstitution([config_path, '41068.rviz'])],
        parameters=[{'use_sim_time': use_sim_time}],
        condition=IfCondition(LaunchConfiguration('rviz'))
    )
    ld.add_action(rviz)

    # === Auto wander with depth camera ===
    auto_wander_depth = Node(
        package='scripts',
        executable='auto_wander_depth',
        name='auto_wander_depth',
        output='screen',
        parameters=[{
            'cmd_vel_topic': 'cmd_vel',
            'depth_topic': '/camera/depth/image',
            'linear_speed': 0.3,
            'angular_speed': 0.6,
            'min_range': 1.0,
            'use_sim_time': use_sim_time
        }]
    )
    ld.add_action(auto_wander_depth)

    return ld
